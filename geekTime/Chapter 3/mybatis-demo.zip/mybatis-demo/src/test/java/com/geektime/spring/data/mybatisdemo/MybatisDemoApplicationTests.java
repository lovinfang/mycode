package com.geektime.spring.data.mybatisdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
