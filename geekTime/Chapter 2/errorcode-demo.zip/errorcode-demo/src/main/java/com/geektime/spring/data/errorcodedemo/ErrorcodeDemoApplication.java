package com.geektime.spring.data.errorcodedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErrorcodeDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErrorcodeDemoApplication.class, args);
	}

}
