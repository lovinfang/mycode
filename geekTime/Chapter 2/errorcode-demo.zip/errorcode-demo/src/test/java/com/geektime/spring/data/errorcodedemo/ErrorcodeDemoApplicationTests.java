package com.geektime.spring.data.errorcodedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErrorcodeDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
