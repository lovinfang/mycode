package com.geektime.spring.data.multidatasourcedemo.multidatasourcedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiDatasourceDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
