/** 
 * @Project     spring-boot-web 
 * @File        package-info.java 
 * @Package     com.dongnao.jack.config 
 * @Version     V1.0 
 * @Date        2017年8月28日 下午2:43:41 
 * @Author      动脑学院-jack 
 */

/** 
 * @Description TODO 
 * @ClassName   package-info 
 * @Date        2017年8月28日 下午2:43:41 
 * @Author      动脑学院-jack
 */

package com.dongnao.jack.config;