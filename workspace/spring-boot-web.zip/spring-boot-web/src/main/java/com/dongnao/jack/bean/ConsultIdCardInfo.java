package com.dongnao.jack.bean;

public class ConsultIdCardInfo {
    public Integer innerId;
    
    public String psptId;
    
    public String name;
    
    public String sex;
    
    public String birthday;
    
    public String address;
    
    public String picture;
    
    public String activeTime;
    
    public String nation;
    
    public Integer getInnerId() {
        return innerId;
    }
    
    public void setInnerId(Integer innerId) {
        this.innerId = innerId;
    }
    
    public String getPsptId() {
        return psptId;
    }
    
    public void setPsptId(String psptId) {
        this.psptId = psptId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getSex() {
        return sex;
    }
    
    public void setSex(String sex) {
        this.sex = sex;
    }
    
    public String getBirthday() {
        return birthday;
    }
    
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getPicture() {
        return picture;
    }
    
    public void setPicture(String picture) {
        this.picture = picture;
    }
    
    public String getActiveTime() {
        return activeTime;
    }
    
    public void setActiveTime(String activeTime) {
        this.activeTime = activeTime;
    }
    
    public String getNation() {
        return nation;
    }
    
    public void setNation(String nation) {
        this.nation = nation;
    }
}
