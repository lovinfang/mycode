package com.dongnao.jack.bean;

public class ConsultContent {
    
    public Integer id;
    
    public Integer itemIndex;
    
    public String content;
    
    public String type;
    
    public Integer state;
    
    public Integer getItemIndex() {
        return itemIndex;
    }
    
    public void setItemIndex(Integer itemIndex) {
        this.itemIndex = itemIndex;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public Integer getState() {
        return state;
    }
    
    public void setState(Integer state) {
        this.state = state;
    }
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
}
