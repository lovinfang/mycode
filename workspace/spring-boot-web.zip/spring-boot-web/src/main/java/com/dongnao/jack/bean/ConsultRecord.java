package com.dongnao.jack.bean;

public class ConsultRecord {
    
    public Integer id;
    
    public String psptId;
    
    public String name;
    
    public String activeTime;
    
    public String autograph;
    
    public String ispass;
    
    public String docautograph;
    
    public String fingerprint;
    
    public String printFlag;
    
    public String remark;
    
    public String getPsptId() {
        return psptId;
    }
    
    public void setPsptId(String psptId) {
        this.psptId = psptId;
    }
    
    public String getActiveTime() {
        return activeTime;
    }
    
    public void setActiveTime(String activeTime) {
        this.activeTime = activeTime;
    }
    
    public String getAutograph() {
        return autograph;
    }
    
    public void setAutograph(String autograph) {
        this.autograph = autograph;
    }
    
    public String getIspass() {
        return ispass;
    }
    
    public void setIspass(String ispass) {
        this.ispass = ispass;
    }
    
    public String getDocautograph() {
        return docautograph;
    }
    
    public void setDocautograph(String docautograph) {
        this.docautograph = docautograph;
    }
    
    public String getFingerprint() {
        return fingerprint;
    }
    
    public void setFingerprint(String fingerprint) {
        this.fingerprint = fingerprint;
    }
    
    public String getPrintFlag() {
        return printFlag;
    }
    
    public void setPrintFlag(String printFlag) {
        this.printFlag = printFlag;
    }
    
    public String getRemark() {
        return remark;
    }
    
    public void setRemark(String remark) {
        this.remark = remark;
    }
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
}
